atletas = [
    {
        "nome": "Lucas",
        "idade": 20,
        "modalidades": ["Natação", "Corrida"],
        "treinos": {"Natação": 12, "Corrida": 8}
    },
    {
        "nome": "Mariana",
        "idade": 25,
        "modalidades": ["Musculação", "Yoga", "Pilates"],
        "treinos": {"Musculação": 15, "Yoga": 10, "Pilates": 5}
    },
    {
        "nome": "João",
        "idade": 22,
        "modalidades": ["Corrida", "Ciclismo"],
        "treinos": {"Corrida": 20, "Ciclismo": 18}
    }
]

def media(esporte):
    idades = [atleta["idade"] for atleta in atletas if esporte in atleta["modalidades"]]
    if not idades:
        return 0
    return sum(idades) / len(idades)

def mais_treinado(atleta):
    return max(atleta["treinos"], key=atleta["treinos"].get)

def mais_modalidades():
    return [atleta["nome"] for atleta in atletas if len(atleta["modalidades"]) > 2]

print("1. Média de idade para 'Corrida':", media("Corrida"))
print("2. Esporte mais treinado por Mariana:", mais_treinado(atletas[1]))
print("3. Atletas com mais de 2 modalidades:", mais_modalidades())
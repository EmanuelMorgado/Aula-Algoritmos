pedidos = [
    {
        "cliente": "Ana",
        "itens": [
            {"prato": "Lasanha", "preco": 30},
            {"prato": "Suco de Laranja", "preco": 8}
        ]
    },
    {
        "cliente": "Bruno",
        "itens": [
            {"prato": "Pizza", "preco": 40},
            {"prato": "Refrigerante", "preco": 6},
            {"prato": "Sobremesa", "preco": 12}
        ]
    },
    {
        "cliente": "Carla",
        "itens": [
            {"prato": "Pizza", "preco": 40},
            {"prato": "Suco de Laranja", "preco": 8}
        ]
    }
]

def total_clientes(nome_cliente):
    for pedido in pedidos:
        if pedido["cliente"] == nome_cliente:
            return sum(item["preco"] for item in pedido["itens"])
    return 0

from collections import Counter

def mais_vendido():
    contador = Counter()
    for pedido in pedidos:
        for item in pedido["itens"]:
            contador[item["prato"]] += 1
    return contador.most_common(1)[0]

def rank():
    gastos = []
    for pedido in pedidos:
        total = sum(item["preco"] for item in pedido["itens"])
        gastos.append((pedido["cliente"], total))
    ranking = sorted(gastos, key=lambda x: x[1], reverse=True)
    return ranking[:3]


print("1. Prato mais vendido:", mais_vendido())
print("2. Top 3 clientes que mais gastaram:")
for i, (cliente, total) in enumerate(rank(), 1):
    print(f"{i}. {cliente} - R$ {total}")

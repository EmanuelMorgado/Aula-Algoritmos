# Lista de músicas
musicas = [
    {
        "titulo": "Back in Black",
        "artista": "AC/DC",
        "downloads": 6800,
        "avaliacoes": [5, 4, 5, 5, 4, 5]
    },
    {
        "titulo": "Stairway to Heaven",
        "artista": "Led Zeppelin",
        "downloads": 8900,
        "avaliacoes": [5, 5, 4, 5, 5]
    },
    {
        "titulo": "Enter Sandman",
        "artista": "Metallica",
        "downloads": 8100,
        "avaliacoes": [5, 5, 4, 5, 4, 5]
    }
]

def nota_media(musica):
    avals = musica["avaliacoes"]
    return sum(avals) / len(avals) if avals else 0

from collections import defaultdict

def mais_baixado(musicas):
    downloads_por_artista = defaultdict(int)
    for musica in musicas:
        downloads_por_artista[musica["artista"]] += musica["downloads"]
    artista_top = max(downloads_por_artista.items(), key=lambda x: x[1])
    return artista_top  # retorna (artista, total_downloads)

def rank(musicas):
    return sorted(
        [(musica["titulo"], nota_media(musica)) for musica in musicas],
        key=lambda x: x[1],
        reverse=True
    )

print("1. Nota média de cada música:")
for m in musicas:
    print(f"{m['titulo']}: {nota_media(m):.2f}")

print("\n2. Mais downloads:")
artista, total =  mais_baixado(musicas)
print(f"{artista} com {total} downloads")

print("\n3. Mais bem avaliadas:")
for i, (titulo, media) in enumerate(rank(musicas), 1):
    print(f"{i}. {titulo} - Média: {media:.2f}")

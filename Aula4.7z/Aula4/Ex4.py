{
    "titulo": "Inception",
    "diretor": "Christopher Nolan",
    "bilheteria": 830,
    "avaliacoes": [9, 10, 8, 9, 10]
}
filmes = [
    {
        "titulo": "Inception",
        "diretor": "Christopher Nolan",
        "bilheteria": 830,
        "avaliacoes": [9, 10, 8, 9, 10]
    },
    {
        "titulo": "Avengers: Endgame",
        "diretor": "Anthony Russo",
        "bilheteria": 2797,
        "avaliacoes": [9, 9, 10, 10, 9]
    },
    {
        "titulo": "The Dark Knight",
        "diretor": "Christopher Nolan",
        "bilheteria": 1005,
        "avaliacoes": [10, 10, 9, 10, 10]
    },
    {
        "titulo": "Jurassic Park",
        "diretor": "Steven Spielberg",
        "bilheteria": 1029,
        "avaliacoes": [8, 9, 9, 8, 9]
    }
]

def media_avaliacao(filme):
    avals = filme["avaliacoes"]
    return sum(avals) / len(avals) if avals else 0

def top_bilheteria(filmes):
    return sorted(filmes, key=lambda f: f["bilheteria"], reverse=True)[:3]

def top_avaliacao(filmes):
    return sorted(filmes, key=media_avaliacao, reverse=True)[:3]

def por_diretor(filmes):
    resultado = {}
    for filme in filmes:
        diretor = filme["diretor"]
        resultado[diretor] = resultado.get(diretor, 0) + filme["bilheteria"]
    return resultado

def campeao(filmes):
    max_bilheteria = max(f["bilheteria"] for f in filmes)
    max_avaliacao = max(media_avaliacao(f) for f in filmes)
    
    def score(filme):
        b_score = filme["bilheteria"] / max_bilheteria
        a_score = media_avaliacao(filme) / max_avaliacao
        return (b_score + a_score) / 2

    return max(filmes, key=score)


print(" Top 3 bilheterias:")
for f in top_bilheteria(filmes):
    print(f"- {f['titulo']} (${f['bilheteria']}M)")

print("\n Top 3 avaliações:")
for f in top_avaliacao(filmes):
    print(f"- {f['titulo']} (Média: {media_avaliacao(f):.2f})")

print("\n Bilheteria por diretor:")
for diretor, total in por_diretor(filmes).items():
    print(f"- {diretor}: ${total}M")

print("\n Campeão absoluto:")
vencedor = campeao(filmes)
print(f"- {vencedor['titulo']} (Bilheteria: ${vencedor['bilheteria']}M, Média: {media_avaliacao(vencedor):.2f})")
